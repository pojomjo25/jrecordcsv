#! /bin/sh

    ##libdir=/home/bm/RecordEdit/HSQLDB/lib
    
    java -jar run.jar net.sf.RecordEditor.editProperties.EditOptions

 
