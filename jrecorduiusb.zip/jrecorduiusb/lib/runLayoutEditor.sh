#! /bin/sh
   
   java -jar "runLayouteditor.jar" 

## if java (1.6.0_03) is stored in the RecordEditor directory
##
## ../../Java/jre1.6.0_03/bin/java -jar runFullEditor.jar 