#! /bin/sh

#    libdir="%INSTALL_PATH/lib"
    
    java -jar "run.jar" net.sf.RecordEditor.copy.CopyDBLayout
    
    
##
##  You could also run the Copy using file layout definitions (i.e. XML or Cobol) with this command
##
##  java -jar "run.jar" net.sf.RecordEditor.copy.CopyFileLayout
##
