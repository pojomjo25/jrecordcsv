#! /bin/sh
    
    java -jar "runFullEditor.jar" ${@}

 
